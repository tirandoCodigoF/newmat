<body>
    <!-- <button id="btnscreen"> boton full scream</button> -->

<iframe id="playbtn" src="https://embed.sdfgnksbounce.com/embed/daznf1.html" allow="autoplay; encrypted-media" scrolling="no" frameborder="0" allowfullscreen> Your browser doesn't support iframes </iframe>
    </body>
    <style>
        body {
    margin: 0;
}
iframe {
    display: block;
    background: #000;
    border: none;
    height: 100vh;
    width: 100vw;
}
    </style>

    <script>
        fullscreen = function(e){
      if (e.webkitRequestFullScreen) {
        e.webkitRequestFullScreen();
      } else if(e.mozRequestFullScreen) {
        e.mozRequestFullScreen();
      }
  }
document.getElementById('btnscreen').onclick = function(){
    fullscreen(document.getElementById('playbtn'));
}

    </script>