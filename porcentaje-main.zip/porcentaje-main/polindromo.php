<!DOCTYPE html>
<html lang="en">
    <head>
        <title>Calcular el Porcentaje | Tics.icu </title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="includes/css/style.css" rel="stylesheet">
        <?php include 'includes/header.php';?>

    </head>
    <body>
    <?php include 'includes/nabvar.php'; ?>
    
    </body>
    <?php include 'includes/footer.php'; ?>
</html>