<script src="plugins/assets/dist/js/bootstrap.bundle.min.js"></script>
<script src="plugins/assets/dist/js/bootstrap.min.js" ></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>