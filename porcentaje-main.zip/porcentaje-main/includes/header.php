<!-- Bootstrap core CSS -->
<link href="plugins/assets/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="plugins/assets/dist/libcarousel/carousel.css" rel="stylesheet">
<script src="https://use.fontawesome.com/161acc0be5.js"></script>