<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-5983271505944424"
     crossorigin="anonymous"></script>