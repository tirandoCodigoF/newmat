$("#btnhide").click(function() {
    $("#contenido").show();
});

$("#closecontenido").click(function() {
    $("#contenido").hide();
});

$("#btnhide2").click(function() {
    $("#contenido2").show();
});

$("#closecontenido2").click(function() {
    $("#contenido2").hide();
});


$("#btnhide4").click(function() {
    $("#contenido4").show();
});

$("#closecontenido4").click(function() {
    $("#contenido4").hide();
});

$("#btnhide5").click(function() {
    $("#contenido5").show();
});

$("#closecontenido5").click(function() {
    $("#contenido5").hide();
});

$("#btnhide6").click(function() {
    $("#contenido6").show();
});

$("#closecontenido6").click(function() {
    $("#contenido6").hide();
});